"""Project Knowledge System core package."""

__version__ = "0.1.14"