from __future__ import annotations

import os
import platform
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

from .config import DEFAULT_EXCLUDES, ProjectConfig
from .engine import BuiltinCodeIndexEngine
from .retrieval import KnowledgeAPI
from .service import ProjectService
from .util import approx_tokens, hash_text, utc_now


REAL_PROJECT_EXCLUDES = [
    ".svn/**",
    "**/.svn/**",
    "**/*.log",
    "**/*.dump",
    "**/*.core",
]


def run_readonly_mirror(source: str | Path, max_files: int | None = None) -> dict[str, Any]:
    source_root = Path(source).resolve()
    if not source_root.is_dir():
        raise ValueError(f"real project source is not a directory: {source_root}")
    config = ProjectConfig(
        project_name=source_root.name,
        exclude=[*DEFAULT_EXCLUDES, *REAL_PROJECT_EXCLUDES],
    )
    engine = BuiltinCodeIndexEngine()
    discovered = engine.discover(source_root, config)
    if max_files is not None:
        if max_files < 1:
            raise ValueError("max_files must be at least 1")
        discovered = discovered[:max_files]
    before = _source_snapshot(source_root)
    inventory = "\n".join(f"{item.path}:{item.content_hash}" for item in discovered)

    with tempfile.TemporaryDirectory(prefix="project-kb-real-mirror-") as temporary:
        mirror = Path(temporary)
        for item in discovered:
            target = mirror / item.path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_root / item.path, target)
        config.write(mirror)
        service = ProjectService(mirror)
        started = time.monotonic()
        initialization = service.initialize()
        initialization_ms = (time.monotonic() - started) * 1000
        api = KnowledgeAPI(mirror)
        context_started = time.monotonic()
        context = api.context("Skynet 服务启动、协议派发和数据持久化入口", max_tokens=2000)
        context_ms = (time.monotonic() - context_started) * 1000
        status = service.status()

    after = _source_snapshot(source_root)
    return {
        "schema_version": 1,
        "generated_at": utc_now(),
        "source": {
            "name": source_root.name,
            "revision": _svn_revision(source_root),
            "inventory_sha256": hash_text(inventory),
            "discovered_files": len(discovered),
            "unchanged": before == after,
            "excluded_patterns": REAL_PROJECT_EXCLUDES,
        },
        "mirror_initialization": {
            "duration_ms": round(initialization_ms, 3),
            "source_files": len(discovered),
            "indexed_files": initialization["files_scanned"],
            "symbols": initialization["symbols"],
            "relations": initialization["relations"],
            "modules": initialization["modules"],
            "parse_errors": initialization["parse_errors"],
            "parse_success_rate": initialization["parse_success_rate"],
        },
        "probe_context": {
            "duration_ms": round(context_ms, 3),
            "estimated_tokens": approx_tokens(str(context)),
            "returned_files": len(context["impact"]["affected_files"]),
            "returned_symbols": len(context["symbols"]),
            "gaps": context["gaps"],
        },
        "index_health": {
            "content_fresh": status["content_fresh"],
            "commit_aligned": status["commit_aligned"],
            "stale_knowledge": status["counts"]["stale_knowledge"],
            "conflicted_knowledge": status["counts"]["conflicted_knowledge"],
        },
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "processor": platform.processor() or "unknown",
            "cpu_count": os.cpu_count(),
        },
        "limitations": [
            "本报告只证明只读镜像初始化和结构事实索引，不证明业务标准答案正确。",
            "Lua/Skynet 专用语义需要 WP-01/WP-02 Adapter 和 D-007 业务审核。",
        ],
    }


def _source_snapshot(root: Path) -> tuple[tuple[str, str, int, int], ...]:
    entries: list[tuple[str, str, int, int]] = []
    for directory, child_directories, names in os.walk(root, topdown=True, followlinks=False):
        base = Path(directory)
        for name in [*child_directories, *names]:
            path = base / name
            stat = path.stat()
            entries.append((
                path.relative_to(root).as_posix(),
                "directory" if path.is_dir() else "file",
                stat.st_size,
                stat.st_mtime_ns,
            ))
    return tuple(sorted(entries))


def _svn_revision(root: Path) -> str | None:
    executable = shutil.which("svn")
    if not executable:
        return None
    completed = subprocess.run(
        [executable, "info", "--show-item", "revision", str(root)],
        cwd=root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return completed.stdout.strip() or None
