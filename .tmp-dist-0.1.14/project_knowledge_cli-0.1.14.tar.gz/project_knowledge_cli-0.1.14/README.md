# Project Knowledge CLI

Project Knowledge System（PKS）是面向代码仓库的本地优先项目知识库。它将源码结构索引到可重建的 SQLite 数据库，生成可追溯到来源的 Markdown 知识，检测可能过期的人工维护知识，并通过只读 MCP 服务器提供精简的任务上下文。

MVP 基于 Python 3.11+，不依赖第三方运行时包。默认配置完全本地运行且禁止网络；只有显式配置、预览并授权 Provider 后，脱敏后的有限 EvidencePack 才允许发送。

## 快速开始

```bash
python -m pip install -e .
project-kb init /path/to/repository
project-kb status /path/to/repository
project-kb mcp --project /path/to/repository
```

初始化会创建 `.project-kb.yml`、本地 `.project-kb/index.db`、版本化清单和 `docs/knowledge`。自动生成的知识可由 PKS 覆盖；人工维护文档的初始模板创建后，PKS 不会静默修改其正文。

## 版本管理

项目以 `0.1.0` 为版本基线，采用 `major.minor.patch` 格式。唯一版本源是 `src/project_knowledge/__init__.py`，构建元数据、`project-kb --version` 和 MCP 服务均读取该值。

从下一批修改开始，任何修改或新增内容都需要在同一批变更中递增一次补丁版本号：

```bash
python scripts/bump_version.py "本次变更的中文说明"
```

例如 `0.1.0` 的下一版本是 `0.1.1`。命令会同时更新唯一版本源和 `CHANGELOG.md`；使用 `--dry-run` 可以只预览结果。自动生成知识的重复同步不需要再次递增版本号。

## 命令

```text
project-kb init [path]       初始化并索引仓库
project-kb sync [path]       增量同步已变更文件
project-kb rebuild [path]    原子重建索引
project-kb watch [path]      轮询变更并进行同步
project-kb status [path]     显示索引和知识库健康状态
project-kb check [path]      执行 CI 健康检查
project-kb install [path]    安装 AGENTS.md 和 MCP 集成提示
project-kb uninstall [path]  仅移除 PKS 拥有的集成标记
project-kb doctor [path]     检查本地运行环境和项目配置
project-kb mcp              运行只读 stdio MCP 服务器
project-kb evaluate         使用 JSONL 问题集评估检索效果
project-kb generate         预览或执行有限证据包的结构化语义生成
project-kb feature-candidates  从代码索引发现待语义生成的功能域候选
project-kb propose [range]  从 Feature Guide 草案或结构化 Patch 创建审核提案
project-kb apply <id>       预览或应用已审核提案
project-kb reject <id>      拒绝提案并保留审计记录
```

所有写入命令均支持 `--dry-run`、`--json` 和 `--quiet`。使用 `project-kb <command> --help` 查看特定命令的选项。

## 评测与质量门

快速集包含 40 条中文开发问题，可分别运行混合检索、grep + Read、仅代码和仅 Markdown 基线。未安装真实 Adapter 时，codegraph 策略会明确报告不可用，不会静默回退。

```bash
project-kb evaluate evaluation/questions.jsonl \
  --project . \
  --strategy all \
  --thresholds evaluation/thresholds.json \
  --baseline evaluation/baselines/self-repo-0.1.8.json \
  --output evaluation/reports/latest.json
```

完整指标、阈值语义、500/5000 文件性能命令和真实项目只读规则见[评测指南](docs/evaluation-guide.md)。

Provider 默认禁用。EvidencePack 的稳定哈希、Token/文件限制、Secret 脱敏、本地 HTTP 接口和云端显式授权规则见[Provider 与 EvidencePack 指南](docs/provider-guide.md)。

## 功能开发指南草案

初始化后，可以先从确定性代码索引发现功能域候选，再把有限证据交给已显式启用的 Provider：

```bash
project-kb feature-candidates --project /path/to/repository --json
project-kb generate "开发背包物品使用功能" \
  --project /path/to/repository \
  --file src/bag/service.py \
  --file tests/test_bag.py \
  --dry-run --json
project-kb generate "开发背包物品使用功能" \
  --project /path/to/repository \
  --file src/bag/service.py \
  --file tests/test_bag.py \
  --save-draft --json
```

保存前会依次执行 JSON Schema 和实时来源校验。文件必须存在于 EvidencePack，符号、路径、行号和哈希必须与本地索引一致；已有 Markdown/文本只能标为候选证据。每个确定性陈述必须至少带一个来源，无来源结论必须放入 `unknowns`。通过校验的草案分片保存在 `docs/knowledge/drafts/features/`，可由 `knowledge_search`、`knowledge_get` 和 `knowledge_context` 读取；源码变化后会标记为可能过期。草案仍是 `draft/generated`，只能通过稳定 Proposal ID、来源哈希复核和显式审核进入 curated generated block。完整字段和生命周期见[Feature Guide、Workflow 与 Recipe 指南](docs/feature-guide.md)，审核、冲突、删除和 ADR 规则见[Proposal 审核与知识提升指南](docs/proposal-guide.md)。

## 知识来源标记

人工维护的 Markdown 可以声明来源依赖，而无需将正文所有权交给 PKS：

```markdown
<!-- project-kb:source file="src/auth/service.py" -->
<!-- project-kb:source symbol="src/auth/service.py::AuthService.authenticate" -->
```

PKS 会在 `.project-kb/manifest.json` 中记录当前来源哈希。来源发生变更时状态变为 `potentially_stale`，来源被删除时状态变为 `stale`。

## MCP 工具

服务器提供 `knowledge_context`、`knowledge_search`、`knowledge_get`、`knowledge_impact` 和 `knowledge_status`。工具结果包含可信度、新鲜度和来源引用。服务器通过 stdio 支持逐行 JSON-RPC，同时兼容当前无状态请求格式和旧版 `initialize` 客户端。

架构、系统保证和路线图请参阅[系统设计文档](docs/project-knowledge-system-design.md)。

当前实现与原始需求的逐项完成度、关键缺口、工作包依赖和后续验收标准，请参阅[需求对齐审计与后续实施基线](docs/project-knowledge-system-audit.md)。后续功能开发以该审计报告为执行清单。
