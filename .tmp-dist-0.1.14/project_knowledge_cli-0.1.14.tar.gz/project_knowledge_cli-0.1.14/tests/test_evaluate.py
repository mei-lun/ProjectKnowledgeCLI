from __future__ import annotations

import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from project_knowledge.cli import main
from project_knowledge.evaluate import (
    evaluate,
    evaluate_quality_gate,
    evaluate_suite,
    load_dataset,
)
from project_knowledge.performance import run_performance_harness
from project_knowledge.real_project import run_readonly_mirror
from project_knowledge.service import ProjectService


SOURCE = '''
class Repository:
    def save(self, value):
        return value

class AccountService:
    def login(self, player_id):
        return Repository().save(player_id)
'''


class EvaluationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        (self.root / "src").mkdir()
        (self.root / "src" / "app.py").write_text(SOURCE, encoding="utf-8")
        (self.root / "pyproject.toml").write_text("[project]\nname='evaluation-fixture'\n", encoding="utf-8")
        ProjectService(self.root).initialize()
        self.dataset = self.root / "questions.jsonl"
        self.dataset.write_text(
            json.dumps({
                "schema_version": 1,
                "id": "account-login",
                "task": "AccountService.login 如何调用 Repository.save？",
                "category": "call_path",
                "expected_files": ["src/app.py"],
                "expected_symbols": ["src/app.py::AccountService.login"],
                "expected_call_path": [
                    "src/app.py::AccountService.login",
                    "src/app.py::Repository.save",
                ],
            }, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_dataset_requires_stable_ids_categories_and_expectations(self) -> None:
        loaded = load_dataset(self.dataset)
        self.assertEqual(loaded[0]["id"], "account-login")
        invalid = self.root / "invalid.jsonl"
        invalid.write_text('{"task":"missing metadata"}\n', encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "line 1"):
            load_dataset(invalid)

    def test_report_contains_anchor_semantic_cost_and_reproducibility_metrics(self) -> None:
        report = evaluate(self.root, self.dataset, strategy="hybrid")
        self.assertEqual(report["schema_version"], 1)
        self.assertEqual(report["strategy"], "hybrid")
        self.assertEqual(report["samples"], 1)
        self.assertIn("file_recall", report["metrics"])
        self.assertIn("call_path_recall", report["metrics"])
        self.assertIn("success_rate", report["metrics"])
        self.assertIn("average_tool_calls", report["metrics"])
        self.assertIn("p95_latency_ms", report["metrics"])
        self.assertIn("dataset_sha256", report["reproducibility"])
        self.assertGreaterEqual(report["reproducibility"]["project_files"], 2)
        self.assertEqual(report["results"][0]["id"], "account-login")

    def test_strategy_suite_isolates_grep_code_markdown_and_unavailable_codegraph(self) -> None:
        suite = evaluate_suite(
            self.root,
            self.dataset,
            strategies=["hybrid", "grep_read", "code", "markdown", "codegraph"],
        )
        self.assertEqual(set(suite["strategies"]), {"hybrid", "grep_read", "code", "markdown", "codegraph"})
        self.assertFalse(suite["strategies"]["codegraph"]["available"])
        self.assertEqual(suite["strategies"]["codegraph"]["reason_code"], "adapter_unavailable")
        self.assertTrue(suite["strategies"]["grep_read"]["available"])
        self.assertIn("src/app.py", suite["strategies"]["grep_read"]["results"][0]["returned_files"])

    def test_quality_gate_checks_thresholds_and_baseline_regression(self) -> None:
        report = {
            "strategies": {
                "hybrid": {"available": True, "samples": 20, "metrics": {
                    "file_recall": 0.7,
                    "success_rate": 0.5,
                    "average_context_tokens": 1000,
                }},
                "codegraph": {"available": False, "reason_code": "adapter_unavailable"},
            }
        }
        thresholds = {
            "minimum_samples": 20,
            "required_strategies": ["hybrid"],
            "allowed_unavailable_strategies": ["codegraph"],
            "minimum": {"file_recall": 0.6, "success_rate": 0.4},
            "maximum": {"average_context_tokens": 1200},
            "strategies": {"hybrid": {"minimum": {"file_recall": 0.65}}},
            "allowed_regression": {"file_recall": 0.02},
        }
        baseline = {"strategies": {"hybrid": {"metrics": {"file_recall": 0.75}}}}
        gate = evaluate_quality_gate(report, thresholds, baseline)
        self.assertFalse(gate["passed"])
        self.assertTrue(any(item["code"] == "metric_regression" for item in gate["failures"]))

        baseline["strategies"]["hybrid"]["metrics"]["file_recall"] = 0.71
        self.assertTrue(evaluate_quality_gate(report, thresholds, baseline)["passed"])

    def test_quality_gate_does_not_compare_aggregate_regression_across_different_datasets(self) -> None:
        report = {
            "dataset_sha256": "sha256:new",
            "strategies": {"hybrid": {"available": True, "samples": 25, "metrics": {"file_recall": 0.7}}},
        }
        baseline = {
            "dataset_sha256": "sha256:old",
            "strategies": {"hybrid": {"metrics": {"file_recall": 0.9}}},
        }
        thresholds = {
            "minimum_samples": 20,
            "required_strategies": ["hybrid"],
            "minimum": {"file_recall": 0.6},
            "allowed_regression": {"file_recall": 0.02},
        }
        gate = evaluate_quality_gate(report, thresholds, baseline)
        self.assertTrue(gate["passed"])
        self.assertFalse(any(item["code"] == "metric_regression" for item in gate["failures"]))
        self.assertTrue(any(item["code"] == "baseline_dataset_mismatch" for item in gate["warnings"]))

    def test_markdown_strategy_respects_sample_token_budget(self) -> None:
        sample = json.loads(self.dataset.read_text(encoding="utf-8"))
        sample["max_tokens"] = 256
        self.dataset.write_text(json.dumps(sample, ensure_ascii=False) + "\n", encoding="utf-8")
        report = evaluate(self.root, self.dataset, strategy="markdown")
        self.assertLessEqual(report["results"][0]["estimated_context_tokens"], 256)

    def test_cli_returns_two_when_quality_gate_fails(self) -> None:
        thresholds = self.root / "thresholds.json"
        thresholds.write_text(json.dumps({
            "minimum_samples": 20,
            "required_strategies": ["hybrid"],
            "minimum": {},
            "maximum": {},
        }), encoding="utf-8")
        with redirect_stdout(io.StringIO()):
            exit_code = main([
                "evaluate", str(self.dataset), "--project", str(self.root),
                "--strategy", "hybrid", "--thresholds", str(thresholds), "--quiet",
            ])
        self.assertEqual(exit_code, 2)

    def test_small_performance_harness_reports_percentiles_and_stale_probe(self) -> None:
        report = run_performance_harness([10], repetitions=2)
        result = report["results"][0]
        self.assertEqual(result["file_count"], 10)
        self.assertIn("p95_ms", result["status"])
        self.assertIn("p95_ms", result["context"])
        self.assertEqual(result["stale_detection"]["passed"], True)

    def test_real_project_harness_indexes_temporary_mirror_without_writing_source(self) -> None:
        source = self.root / "real-source"
        source.mkdir()
        for number in range(5):
            (source / f"service_{number}.lua").write_text(
                f"local M = {{}}\nfunction M.run() return {number} end\nreturn M\n",
                encoding="utf-8",
            )
        svn = source / ".svn"
        svn.mkdir()
        (svn / "entries").write_text("private metadata", encoding="utf-8")
        before = sorted(path.relative_to(source).as_posix() for path in source.rglob("*"))
        report = run_readonly_mirror(source)
        after = sorted(path.relative_to(source).as_posix() for path in source.rglob("*"))
        self.assertEqual(before, after)
        self.assertTrue(report["source"]["unchanged"])
        self.assertEqual(report["source"]["discovered_files"], 5)
        self.assertEqual(report["mirror_initialization"]["source_files"], 5)
        self.assertEqual(report["mirror_initialization"]["indexed_files"], 6)


if __name__ == "__main__":
    unittest.main()
